package com.htb.hosting.rmi;

import java.io.File;

/* loaded from: registry.jar:com/htb/hosting/rmi/FileServiceConstants.class */
public class FileServiceConstants {
   public static final File SITES_DIRECTORY = new File("/sites");
}