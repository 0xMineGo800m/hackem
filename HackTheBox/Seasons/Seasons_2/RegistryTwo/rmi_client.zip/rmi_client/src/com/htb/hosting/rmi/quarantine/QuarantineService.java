package com.htb.hosting.rmi.quarantine;

import java.rmi.Remote;
import java.rmi.RemoteException;

/* loaded from: registry.jar:com/htb/hosting/rmi/quarantine/QuarantineService.class */
public interface QuarantineService extends Remote {
    QuarantineConfiguration getConfiguration() throws RemoteException;
}