package com.htb.hosting.rmi;

import java.io.IOException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface FileService extends Remote {
    List<AbstractFile> list(String str, String str2) throws RemoteException;

    boolean uploadFile(String str, String str2, byte[] bArr) throws IOException;

    boolean delete(String str) throws RemoteException;

    boolean createDirectory(String str, String str2) throws RemoteException;

    byte[] view(String str, String str2) throws IOException;

    AbstractFile getFile(String str, String str2) throws RemoteException;

    AbstractFile getFile(String str) throws RemoteException;

    void deleteDomain(String str) throws RemoteException;

    boolean newDomain(String str) throws RemoteException;

    byte[] view(String str) throws RemoteException;
}