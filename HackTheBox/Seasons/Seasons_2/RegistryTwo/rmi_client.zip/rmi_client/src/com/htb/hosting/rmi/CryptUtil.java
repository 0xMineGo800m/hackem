package com.htb.hosting.rmi;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

/* loaded from: hosting.war:WEB-INF/classes/com/htb/hosting/utils/CryptUtil.class */
public class CryptUtil {
    public static CryptUtil instance = new CryptUtil();
    Cipher ecipher;
    Cipher dcipher;
    byte[] salt = {-87, -101, -56, 50, 86, 53, -29, 3};
    int iterationCount = 19;
    String secretKey = "48gREsTkb1evb3J8UfP7";

    public static CryptUtil getInstance() {
        return instance;
    }

    public String encrypt(String plainText) {
        try {
            KeySpec keySpec = new PBEKeySpec(this.secretKey.toCharArray(), this.salt, this.iterationCount);
            SecretKey key = SecretKeyFactory.getInstance("PBEWithMD5AndDES").generateSecret(keySpec);
            AlgorithmParameterSpec paramSpec = new PBEParameterSpec(this.salt, this.iterationCount);
            this.ecipher = Cipher.getInstance(key.getAlgorithm());
            this.ecipher.init(1, key, paramSpec);
            byte[] in = plainText.getBytes("UTF-8");
            byte[] out = this.ecipher.doFinal(in);
            String encStr = Base64.getUrlEncoder().encodeToString(out);
            return encStr;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public String decrypt(String encryptedText) throws NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, UnsupportedEncodingException, IllegalBlockSizeException, BadPaddingException, IOException {
        KeySpec keySpec = new PBEKeySpec(this.secretKey.toCharArray(), this.salt, this.iterationCount);
        SecretKey key = SecretKeyFactory.getInstance("PBEWithMD5AndDES").generateSecret(keySpec);
        AlgorithmParameterSpec paramSpec = new PBEParameterSpec(this.salt, this.iterationCount);
        this.dcipher = Cipher.getInstance(key.getAlgorithm());
        this.dcipher.init(2, key, paramSpec);
        byte[] enc = Base64.getUrlDecoder().decode(encryptedText);
        byte[] utf8 = this.dcipher.doFinal(enc);
        String plainStr = new String(utf8, "UTF-8");
        return plainStr;
    }
}