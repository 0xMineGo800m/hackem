package com.htb.hosting.rmi;

import com.htb.hosting.rmi.quarantine.QuarantineConfiguration;
import com.htb.hosting.rmi.quarantine.QuarantineService;

import java.nio.charset.StandardCharsets;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.List;


public class Client {
    private Client() {
    }

    public static void main(String[] args) {
        System.out.println("Inside main");
        try {

            if (args.length > 0) {
                final String command = args[0];
                if ("view".equalsIgnoreCase(command) || "ls".equalsIgnoreCase(command)) {

                    Registry registry = LocateRegistry.getRegistry("127.0.0.1", 9002);
                    System.out.println("We got registry");
                    FileService fileService = (FileService) registry.lookup("FileService");
                    System.out.println("We got FileService");

                    switch (command) {
                        case "view": {
                            String domainId = args[1];
                            String fileName = args[2];
                            System.out.println("DomainId: " + domainId + " fileName: " + fileName);
                            byte[] content = fileService.view(domainId, fileName);
                            String text = new String(content, StandardCharsets.UTF_8);
                            System.out.println(text);
                            break;
                        }
                        case "ls":
                            String domainId = args[1];
                            String fileName = args[2];
                            System.out.println("DomainId: " + domainId + " fileName: " + fileName);
                            List<AbstractFile> list = fileService.list(domainId, fileName);
                            for (AbstractFile f : list) {
                                System.out.println(f.getDisplayName());
                            }
                            break;
                        default:
                            System.out.println("Command given unknown: " + command);
                            break;
                    }
                }
            } else {
                Registry registry = LocateRegistry.getRegistry("127.0.0.1", 9002);
                System.out.println("We got registry");
                QuarantineService quarantineService = (QuarantineService) registry.lookup("QuarantineService");
                System.out.println("We got QuarantineService");
                QuarantineConfiguration configuration = quarantineService.getConfiguration();
                System.out.println(configuration.toString());
            }
        } catch (Exception e) {
            System.err.println("Client exception: " + e);
            e.printStackTrace();
        }
    }
}
