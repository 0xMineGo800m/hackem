package com.htb.hosting.rmi.quarantine;

import java.io.File;
import java.io.Serializable;

public class QuarantineConfiguration implements Serializable {
   private final File quarantineDirectory;
   private final File monitorDirectory;
   private final String clamHost;
   private final int clamPort;
   private final int clamTimeout;

   public QuarantineConfiguration(File quarantineDirectory, File monitorDirectory, String clamHost, int clamPort, int clamTimeout) {
      this.quarantineDirectory = quarantineDirectory;
      this.monitorDirectory = monitorDirectory;
      this.clamHost = clamHost;
      this.clamPort = clamPort;
      this.clamTimeout = clamTimeout;
   }

   public boolean equals(Object o) {
      if (o == this) {
         return true;
      }
      if (o instanceof QuarantineConfiguration) {
         QuarantineConfiguration other = (QuarantineConfiguration) o;
         if (other.canEqual(this) && getClamPort() == other.getClamPort() && getClamTimeout() == other.getClamTimeout()) {
            Object this$quarantineDirectory = getQuarantineDirectory();
            Object other$quarantineDirectory = other.getQuarantineDirectory();
            if (this$quarantineDirectory == null) {
               if (other$quarantineDirectory != null) {
                  return false;
               }
            } else if (!this$quarantineDirectory.equals(other$quarantineDirectory)) {
               return false;
            }
            Object this$monitorDirectory = getMonitorDirectory();
            Object other$monitorDirectory = other.getMonitorDirectory();
            if (this$monitorDirectory == null) {
               if (other$monitorDirectory != null) {
                  return false;
               }
            } else if (!this$monitorDirectory.equals(other$monitorDirectory)) {
               return false;
            }
            Object this$clamHost = getClamHost();
            Object other$clamHost = other.getClamHost();
            return this$clamHost == null ? other$clamHost == null : this$clamHost.equals(other$clamHost);
         }
         return false;
      }
      return false;
   }

   protected boolean canEqual(Object other) {
      return other instanceof QuarantineConfiguration;
   }

   public int hashCode() {
      int result = (1 * 59) + getClamPort();
      int result2 = (result * 59) + getClamTimeout();
      Object $quarantineDirectory = getQuarantineDirectory();
      int result3 = (result2 * 59) + ($quarantineDirectory == null ? 43 : $quarantineDirectory.hashCode());
      Object $monitorDirectory = getMonitorDirectory();
      int result4 = (result3 * 59) + ($monitorDirectory == null ? 43 : $monitorDirectory.hashCode());
      Object $clamHost = getClamHost();
      return (result4 * 59) + ($clamHost == null ? 43 : $clamHost.hashCode());
   }

   public String toString() {
      return "QuarantineConfiguration(quarantineDirectory=" + getQuarantineDirectory() + ", monitorDirectory=" + getMonitorDirectory() + ", clamHost=" + getClamHost() + ", clamPort=" + getClamPort() + ", clamTimeout=" + getClamTimeout() + ")";
   }

   public File getQuarantineDirectory() {
      return this.quarantineDirectory;
   }

   public File getMonitorDirectory() {
      return this.monitorDirectory;
   }

   public String getClamHost() {
      return this.clamHost;
   }

   public int getClamPort() {
      return this.clamPort;
   }

   public int getClamTimeout() {
      return this.clamTimeout;
   }
}